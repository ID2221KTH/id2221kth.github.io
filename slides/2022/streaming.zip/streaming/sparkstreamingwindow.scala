/**
 * To run this on your local machine, you need to first run a Netcat server
 *    `$ nc -lk 9999`
 */

import org.apache.spark.SparkConf
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.logging.log4j.Level
import org.apache.logging.log4j.core.config.Configurator
import org.apache.spark.internal.Logging

object NetworkWordCountWindow {
  def main(args: Array[String]): Unit = {

	Configurator.setRootLevel(Level.WARN)
    
    // Create the context with a 1 second batch size
    val sparkConf = new SparkConf().setMaster("local[2]").setAppName("NetworkWordCount")
    val ssc = new StreamingContext(sparkConf, Seconds(1))

    val lines = ssc.socketTextStream("localhost", 9999, StorageLevel.MEMORY_AND_DISK_SER)
    val words = lines.flatMap(_.split(" "))
    val pairs = words.map(x => (x, 1))
    val wordCounts = pairs.reduceByKeyAndWindow((a: Int, b: Int) => (a + b), Seconds(3), Seconds(1))
    wordCounts.print()
    ssc.start()
    ssc.awaitTermination()
  }
}

